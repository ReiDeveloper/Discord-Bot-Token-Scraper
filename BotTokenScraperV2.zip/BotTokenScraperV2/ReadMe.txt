

* Credits *
-----------------

THIS IS NOT MADE BY ME IT IS MADE BY 
mat1.

But this is edited a litle bit by me.

here is his replit

https://repl.it/@mat1/token-finder




* Installation *

------------------

to install 

go on your cmd prompt (windows 10 and above only)
and type in this (you must have pip installed)

pip install BeautifulSoup

then pip install bs4

and pip install termcolor
 

then open run.bat and it will start scraping..

then after its done, go check tokens.txt for the scraped tokens.


IF you need anymore help, just put it in issues.

